import java.util.Arrays;

/*Course: CS 27500
* Name: Sreypov Ing
* Email: ings@pnw.edu
* Assignment: 3
*/

// This is an assignment for students to complete after reading Chapter 4
// of "Data Structures and Other Objects Using Java" by Michael Main.

/**
* This class is a homework assignment;
* A <CODE>IntLinkedSeq</CODE> is a collection of <CODE>int</CODE> numbers.
* The sequence can have a special "current element," which is specified and
* accessed through four methods (start, getCurrent, advance, and isCurrent).
*
* <dl>
* <dt><b>Limitations:</b>
* <dd> Beyond Int.MAX_VALUE</CODE> elements, the <CODE>size</CODE> method
*      does not work.
*
* <dt><b>Note:</b>
* <dd> This file contains only blank implementations ("stubs")
*      because this is a Programming Project for students.
*/
public class IntLinkedSeq extends IntSeq
{
   private int manyItems;  // how many nodes are in this sequence
   private IntNode head;   // reference to the first node of the sequence
   private IntNode tail;   // reference to the last node of the sequence
   private IntNode cursor; // reference to the "current" node (null
                           // if there isn't one)

   /**
   * Initialize an empty sequence.
   *
   * @param none
   * @postcondition
   *   This sequence is empty. It does not have a current element.
   **/
   public IntLinkedSeq( )
   {
     head = null;
     tail = null;
     cursor = null;
   
   }


   /**
   * Copy Constructor
   *
   * @param otherSequence
   *   Sequence to make a deep copy of.
   *
   * @postcondition
   *   This sequence is a DEEP copy of the parameter sequence.
   *   Subsequent changes to the copy will not affect the original, nor vice versa.
   *   The copy should have its cursor set in the appropriate
   *   place within its linked list.
   **/
   public IntLinkedSeq(IntLinkedSeq otherSequence)
   {
    int[] anArray = otherSequence.toArray();
    IntNode newNode = new IntNode(anArray[0], null);
    head = newNode;
    IntNode cur = head;
    tail = head;
    int index = 0;
    
    manyItems = anArray.length;
    for(int i = 1; i < anArray.length; i++){
     IntNode nextNode = new IntNode (anArray[i],null);
     cur.setLink(nextNode);
     if(otherSequence.cursor != null && otherSequence.cursor.getData() == anArray[i])
     {
      index = i;
     }
     cur = nextNode;
     tail = nextNode;
    }
    
    if(otherSequence.cursor != null){
     setCurrent(index);
    }
    else{
     cursor = null;
    }
   }



   /**
   * {@inheritDoc}
   */
   public void addAfter(int element)
   {
    IntNode node = null;
    if(isCurrent ()){
     node = cursor;
    }
    else{
     addFirst(element);
    }
    if(node != null){
     IntNode current = new IntNode(element, cursor.getLink());
     node.setLink(current);
     if(cursor == tail){
      tail = current;
     }
     cursor = current;
     manyItems++;
     
    }
      

   }


   /**
   * {@inheritDoc}
   */
   public void addBefore(int element)
   {
    if(head == null){
     addFirst(element);
    }
    else{
     IntNode prev = null;
     IntNode cur = head;
     if(head == cursor | head == tail){
      head = new IntNode(element, cur);
      cursor = head;
      manyItems++;
     }
     else{
      while(cur!= null){
       prev = cur;
       cur = cur.getLink();
       
       if(cur == cursor){
        IntNode current = new IntNode(element,cur);
        prev.setLink(current);
        cursor = current;
        break;
       }
      }
      manyItems++;
     }
    }

   }


   /**
   * {@inheritDoc}
   */
   public void addAll(IntSeq addend)
   {
    int[] anArray = addend.toArray();
    for(int i = 0; i < anArray.length; i++){
     addLast(anArray[i]);
    }

   }


   /**
   * {@inheritDoc}
   */
   public void addFirst(int element)
   {
    if(head == null){
     head = new IntNode(element, null);
     tail = head;
    }
    else{
     head = new IntNode(element, head);
    }
    manyItems++;

   }


   /**
   * {@inheritDoc}
   */
   public void addLast(int element)
   {
    if(head == null){
     addFirst(element);
    }
    else{
     IntNode node = head;
     while(node != null){
      node = node.getLink();
      if(node == tail){
       IntNode newTail = new IntNode(element, null);
       node.setLink(newTail);
       tail = newTail;
       break;
      }
     }
     manyItems++;
    }
   }


   /**
   * {@inheritDoc}
   */
   public void start( )
   {
    if(head != null){
     cursor = head;
    }

   }


   /**
   * {@inheritDoc}
   */
   public boolean isCurrent( )
   {
    if(cursor != null){
     return true;
    }
    else{
     
    }
      return false; 
   }


   /**
   * {@inheritDoc}
   */
   public int getCurrentValue( )
   {
    if(!isCurrent()){
     throw new IllegalStateException("There is no current element.");
    }
    else{
     return cursor.getData();
    }
     
   }


   /**
   * {@inheritDoc}
   */
   public void setCurrentValue(int element)
   {
    if (!isCurrent()){
     throw new IllegalStateException("There is no current element.");
    }
    else{
     cursor.setData(element);
    }

   }


   /**
   * {@inheritDoc}
   */
   public void removeCurrent( )
   {
   if(!isCurrent()){
    throw new IllegalStateException("There is no current element.");
   }
   else{
    IntNode cur = head;
    IntNode prev = null;
    while(cur != null){
     prev = cur;
     cur = cur.getLink();
     if(cur == cursor && cur == tail){
      prev.setLink(null);
      cursor = null;
     }
     else{
      if(cur == cursor){
       if(cursor != null){
        cursor = cur.getLink();
        prev.setLink(cursor);
        break;
       }
      }
     }
    }
    manyItems--;
   }

   }


   /**
   * {@inheritDoc}
   */
   public void removeFirst( )
   {
    if(head == null){
     throw new IllegalStateException("The sequence can be empty.");
    }
    if(head == tail){
     tail = null;
     head = null;
    }
    else{
     if(head == cursor){
      invalidateCurrent();
     }
     IntNode node = head.getLink();
     head = node;
     
    }
    manyItems--;
   }


   /**
   * {@inheritDoc}
   */
   public void removeLast( )
   {
   if(head == null){
    throw new IllegalStateException("The sequence cannot be empty.");
   }
   if(tail == head){
    if(tail == cursor){
     invalidateCurrent();
    }
    head = null;
    tail = null;
   }
   else{
    IntNode node = head;
    IntNode prev = null;
    
    while(node != tail){
     prev = node;
     node = node.getLink();
    }
    if(node == cursor){
     invalidateCurrent();
    }
    prev.setLink(null);
    tail = prev;
   }
   manyItems--;
   
   }


   /**
   * {@inheritDoc}
   */
   public void advance( )
   {
    if(!isCurrent()){
     throw new IllegalStateException("There is no current element.");
    }
    else{
     if(cursor == tail){
      cursor = null;
     }
     else{
      cursor = cursor.getLink();
     }
    }


   }


   /**
   * {@inheritDoc}
   */
   public void setCurrent(int i)
   {
   if(i < 0 || i > (size() - 1)){
    throw new IndexOutOfBoundsException("Index must be greater than zero and less than" + (size() - 1));
   }
   
   IntNode node = head;
   int count = 0;
   
   if( i >= 0 && i < manyItems){
    while(node != null){
     if(i == count){
      cursor = node;
      break;
     }
     count++;
     node = node.getLink();
    }
   }

   }


   /**
   * {@inheritDoc}
   */
   public void invalidateCurrent( )
   {
    cursor = null;

   }


   /**
   * {@inheritDoc}
   */
   public boolean contains(int target)
   {
    IntNode node = head;
    
    while(node != null){
     if(node.getData() == target){
      return true;
     }
     node = node.getLink();
    }

      return false; 
   }


   /**
   * {@inheritDoc}
   */
   public int indexOf(int target)
   {
    int[] anArray = toArray();
    int i = 0;
    for(; i < anArray.length; i++){
     if(target == cursor.getData()){
      break;
     }
    }
    return i;

      
   }


   /**
   * {@inheritDoc}
   */
   public int size( )
   {
      return manyItems; 
   }



   /**
   * {@inheritDoc}
   */
   public IntSeq catenation(IntSeq s2)
   {
   int[] s2Array = s2.toArray();
   System.out.println("Seq1 size" + size ());
   int[] anArray = toArray();
   IntSeq cur = new IntLinkedSeq();
   cur.addFirst(anArray[0]);
   cur.setCurrent(0);
   
   for(int i = 1; i < anArray.length; i++){
    cur.addAfter(anArray[i]);
   }
   for(int i = 0; i < s2Array.length; i++){
    cur.addAfter(s2Array[i]);
   }
   cur.invalidateCurrent();
   return cur;
 
   }


   /**
   * {@inheritDoc}
   */
   public IntSeq subSeq(int fromIndex, int toIndex)
   {
    if(fromIndex > toIndex){
     throw new IllegalArgumentException("Endpoint indices are out of order.");
   }
    if(fromIndex < 0 || toIndex > size ()){
     throw new IndexOutOfBoundsException("Endpoint index value out of range.");
    }
    
    int[] anArray = Arrays.copyOfRange(toArray(),fromIndex, toIndex);
    
    IntSeq cur = new IntLinkedSeq();
    cur.addFirst(anArray[0]);
    cur.setCurrent(0);
    manyItems = anArray.length;
    for(int i = 1; i < anArray.length; i++){
     cur.addAfter(anArray[i]);
    }
    
    System.out.println("Size of seq1" + size());
    System.out.println("Size of subseq" + cur.size());
    cur.invalidateCurrent();
    
    return cur;
   }


   /**
   * {@inheritDoc}
   */
   public IntSeq reverse( )
   {
   int[] anArray = toArray();
   
   for(int i = 0; i < anArray.length /2; i++){
    int temp = anArray[i];
    anArray[i] = anArray[anArray.length - 1 - i];
    anArray[anArray.length - 1 -i] = temp;
   }
   
   IntSeq cur = new IntLinkedSeq();
   cur.addFirst(anArray[0]);
   cur.setCurrent(0);
   
   manyItems = anArray.length;
   for(int i = 1; i < anArray.length; i++){
    cur.addAfter(anArray[i]);
   }
   
   cur.invalidateCurrent();
   
   return cur;
   
   }


   /**
   * {@inheritDoc}
   */
   public int[] toArray( )
   {
   int[] data = new int[size ()];
   IntNode cur = head;
   int i = 0;
   while(cur != null){
    data[i] = cur.getData();
    cur = cur.getLink();
    i++;
   }
   return data;
   }



   /**
   * {@inheritDoc}
   */
   public String toString( )
   {
      String result = "[";
      IntNode ptr = head;
      while (ptr != null)
      {
         result += ptr.getData();
         if (ptr == cursor)
         {
            result += "*"; // use a special symbol at the cursor
         }
         ptr = ptr.getLink();
         if (ptr != null)
         {
            result += ", ";
         }
      }
      result += "]";
      return result;
   }

}//IntLinkedSeq
